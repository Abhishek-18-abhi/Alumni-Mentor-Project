import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./frontend/setupTests.js'],
    globals: true,
    include: ['frontend/**/*.{test,spec}.{js,jsx}'],
  },
});
