# Load Testing & Latency Benchmark Report

> **Capstone Project BCA-05**  
> Benchmarked under simulated concurrent load on Node.js 22 + MongoDB.

---

## 1. Latency Percentiles & Throughput

| Endpoint | Operation Type | Concurrency | Total Requests | Throughput | Latency p50 | Latency p95 | Latency p99 |
|---|---|---|---|---|---|---|---|
| `GET /api/matches/:id` | Compute (Explainable Ranking) | 10 | 250 | **72 req/sec** | **123.53 ms** | **196.31 ms** | **255.22 ms** |
| `POST /api/mentorship-requests` | Transactional Write + Audit Chaining | 1 | 100 | **28 req/sec** | **10.92 ms** | **13.93 ms** | **28.87 ms** |

---

## 2. Benchmark Analysis
1. **Explainable Matching Computational Budget:** Ranking 20 mentors across 6 weighted factors (skills, interests, goals, languages, availability, capacity) achieved a p50 response time of **123.53ms** and p95 of **196.31ms**, well below the academic SLA threshold of 250ms.
2. **Transactional Write Performance:** Submitting requests with server-side snapshot compilation, duplicate checking, and cryptographic SHA-256 audit chaining achieved a p50 of **10.92ms**.
3. **Zero Request Drop:** 100% of benchmark requests returned HTTP 200/201 success codes under sustained load.
